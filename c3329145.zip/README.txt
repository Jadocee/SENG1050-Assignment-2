Student Number: C3329145

-----------------------------------------------------------
                          Files
-----------------------------------------------------------
Amarok_Exterior_Lifestyle_Towingcableroll.jpg
car-agent-congratulate-the-family-picture-id495593934.jpg   http://www.istockphoto.com/photos/car-dealership
car_dealership.jpg                                          https://www.fool.com/investing/general/2015/05/31/10-best-car-companies-by-auto-sales.aspx (via Brave Image Search)
diego-jimenez-A-NVHPka9Rk-unsplash.jpg                      https://unsplash.com/photos/A-NVHPka9Rk
Golf-GTI-hero-custom.jpg                                    https://www.volkswagen.com.au/en/models/golf-gti.html
iStock_000019786780Large1.jpg                               http://perq.com/making-dealerships-event-sale/ (via Brave Image Search)
jim.png                                                     http://www.theaustralian.com.au (via Brave Image Search)
logowhite.png
MS-Exterior-Hero-Desktop.jpg                                https://www.tesla.com/
MS-Hero-Mobile.jpg                                          https://www.tesla.com/
ms-main-hero-desktop.jpg                                    https://www.tesla.com/
MX-Hero-Desktop.jpg                                         https://www.tesla.com/
MX-Performance-Hero-Desktop.jpg                             https://www.tesla.com/
T-Cross_Green_Exterior_Lifestyle_Exterior.jpg               https://www.volkswagen.com.au/en/models/t-cross.html
tesla_model_3_white.jpg                                     https://www.autoexpress.co.uk/tesla/model-3/practicality
jimpenmanstare.jpeg                                         https://au.newschant.com/business/jims-mowing-owner-jim-penman-denies-sending-sexist-letter-to-green-senator-lidia-thorpe/

-----------------------------------------------------------
                        References
-----------------------------------------------------------
Descriptions of services:
    Each description is inspired by the information available at the following sites.
    https://www.jimsmowing.com.au/service/rubbish-removal/
    https://www.jimsmowing.com.au/service/lawn-mowing/
    https://www.jimsmowing.com.au/service/garden-landscaping/
    https://www.jimsmowing.com.au/

Tesla:
    The images and information used in "todays showcase" is copied from https://www.tesla.com/en_au

Safety Ratings:
    https://www.ancap.com.au/safety-ratings/tesla?is_current_model=true&page=1&field=rating_year&direction=desc
    https://www.ancap.com.au/safety-ratings/volkswagen?is_current_model=true&page=1&field=rating_year&direction=desc

Image of Jim Penman:
    https://imgr.search.brave.com/cGnR3c--_D-JEYOg3TZGKqYjt6ykiE2foUWvAX1h8n0/fit/650/366/ce/1/aHR0cDovL3Jlc291/cmNlczAubmV3cy5j/b20uYXUvaW1hZ2Vz/LzIwMTIvMDEvMTkv/MTIyNjI0OC8xODM0/NTItamltLXBlbm1h/bi1qaW0tYW1wLTAz/OS1zLW1vd2luZy5q/cGc (original site is not available)

Copyright Statement:
    Free template provided by https://www.disclaimertemplate.com/free-website-copyright-notice/

About Us Page:
    The 'about us' page used the following site as a template.
    https://www.jimsmowing.com.au/about-us/

Privacy Policy:
    The 'privacy policy' page used a privacy policy generator at https://visser.io/tools/living-in-australia/privacy-policy-generator/

Terms and Conditions:
    The 'terms and conditions' page used a T&C generator at https://visser.io/tools/living-in-australia/privacy-policy-generator/

Contact Us:
    The layout of the 'contact us' page was inspired by https://www.zendesk.com/contact/.

Image of Jim Penman Staring:
    https://au.newschant.com/business/jims-mowing-owner-jim-penman-denies-sending-sexist-letter-to-green-senator-lidia-thorpe/